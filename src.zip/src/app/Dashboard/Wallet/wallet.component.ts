import { Component } from '@angular/core';

 @Component({
    selector : 'wallet-user',
    templateUrl : './wallet.component.html'
 })

 export class UserWalletComponent{
    title : 'Wallet';
 }
