import { Component } from '@angular/core';

 @Component({
    selector : 'change-pass',
    templateUrl : './changepass.component.html'
 })

 export class ChangePassComponent{
    title : 'Change Password';
 }
