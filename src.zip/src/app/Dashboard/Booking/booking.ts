export class Booking{
    constructor(public noOfSeats?: number,
        public email?: string,
        public busid?: number,
        public dateOfBooking?: string,
        public price?: number
        ) { }

}