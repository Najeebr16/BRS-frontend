export class Passenger{
    constructor(public seatNumber?: number,
        public fullname?: string,
        public age?: number,
        public gender?: string,
        public id?: number
        ) { }

}