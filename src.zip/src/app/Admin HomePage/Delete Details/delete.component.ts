import { Component } from '@angular/core';
import { DeleteService } from './delete.service';
import { Router } from '@angular/router';

@Component({
    selector : 'delete-details',
    templateUrl : './delete.component.html',  
 })

 export class DeleteComponent{
    del: string;
    url2 = "";
    constructor(private bs: DeleteService, private r: Router) {
}

   ngOnInit(){
   }
   delete(){
      this.bs.sendToServer(this.url2,this.del).subscribe(
         data => {
         });
      this.r.navigate(['/bus-details'])
   }
 }
