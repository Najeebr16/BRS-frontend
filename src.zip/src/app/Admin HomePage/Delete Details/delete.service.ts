import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable()
export class DeleteService {

    // injecting Angular's HttpClient API
    constructor(private http: HttpClient) {}

   
    // get products from server
    sendToServer(url5,del){
      //our code to be communicated with the server will be here
       return this.http.post(url5,del) 
    }
  
}