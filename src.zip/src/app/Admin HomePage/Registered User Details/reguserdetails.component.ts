import { Component } from '@angular/core';
import { RegUsersDetails } from './reguser';
import { RegUserDetailsService } from './reguserdetails-service';



@Component({
    selector : 'regdetails-user',
    templateUrl : './reguserdetails.component.html'
 })
 export class RegUserDetailsComponent{

    Reguser: RegUsersDetails[];
    emailreg: string;
   
       url2 = "";
   
       constructor(private bs:  RegUserDetailsService) {
   
       }
   
       ngOnInit() {
         this.emailreg = sessionStorage.getItem("emailreg");
         this.bs.retrieveFromServer(this.url2+this.emailreg).subscribe(
            data => {
                console.log(data);
                this.Reguser =  data;
            });
       }
       
       
    }

 