export class RegUsersDetails{
    constructor(
        private id?: number,
        private email?: string,
        private fullname?: string,
        private gender?: string,
        private mobile?: string,
        private address?: string,
        private dateOfBirth?: string,
        private password?: string,
        ) { }

}