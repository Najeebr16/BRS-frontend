import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RegUsersDetails } from './reguser';





@Injectable()
export class RegUserService {
    busesavail: RegUsersDetails[];

    // injecting Angular's HttpClient API
    constructor(private http: HttpClient) {}

    // get products from server
    sendToServer(url5,del){
        //our code to be communicated with the server will be here
         return this.http.post(url5,del) 
      }
}