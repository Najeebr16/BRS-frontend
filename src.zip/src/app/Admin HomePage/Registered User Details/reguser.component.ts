import { Component } from '@angular/core';
import { RegUserService } from './reguser-service';
import { RegUsersDetails } from './reguser';
import { Router } from '@angular/router';

@Component({
    selector : 'reg-user',
    templateUrl : './reguser.component.html'
 })

 export class RegUserComponent{

 Reguser: RegUsersDetails[];

    emailreg: string;
    url2 = "";

    constructor(private bs:  RegUserService , private r: Router  ) {

    }

    ngOnInit() {
    }
    store(){
        sessionStorage.setItem('emailreg',''+this.emailreg);
        this.bs.sendToServer(this.url2,this.emailreg).subscribe(
            data => {
            });
        this.r.navigate(['/regdetails-user']);
    }


    
 }
     
 