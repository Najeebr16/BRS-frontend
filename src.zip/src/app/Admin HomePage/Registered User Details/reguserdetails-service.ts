import { Injectable } from '@angular/core';
import { RegUsersDetails } from './reguser';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class RegUserDetailsService {
    busesavail: RegUsersDetails[];

    // injecting Angular's HttpClient API
    constructor(private http: HttpClient) {}

    // get products from server
    retrieveFromServer(url2) : Observable <RegUsersDetails[]> {
         return this.http.get<RegUsersDetails[]>(url2);
    }
}