import { Component } from '@angular/core';

 @Component({
    selector : 'admin-homepage',
    templateUrl : './Admin-homepage.component.html',
    styleUrls: ['./Admin-homepage.component.css']
 })

 export class AdminComponent{
     title : 'Admin-Home-Page';
 }