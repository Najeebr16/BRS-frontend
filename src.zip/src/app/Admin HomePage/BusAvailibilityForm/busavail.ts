export class BusAvail{
    constructor(
        private busname?: string,
        private source?: string,
        private destination?: string,
        private Tfare?: DoubleRange,
        private day?: string,
        private time?: string,
        private type?: string,
        private timerange?: string,
        ) { }

}