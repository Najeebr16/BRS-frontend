import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { BusAvail } from './busavail';
import { Observable } from 'rxjs';

@Injectable()

export class BusAvailService{
    busavail : BusAvail[];
    
constructor(private http:HttpClient){

}
sendToServer(url,user){
    //our code to be communicated with the server will be here
 return this.http.get(url,user) 
 
  }
}