export class BookingDetails{
    constructor(
        private bookid?: number,
        private id?: string,
        private bus_id?: string,
        private dateOfBooking?: string,
        private numberOfSeats?: string,
        private TotalPrice?: string,
       
        ) { }

}