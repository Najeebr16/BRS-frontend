import { Component } from '@angular/core';
import { BookingDetailsService } from './bookingdetails-service';
import { BookingDetails } from './bookingdetails';

@Component({
    selector : 'booking-details',
    templateUrl : './bookingdetails.component.html'
 })

 export class BookingDetailsComponent{

    book: BookingDetails[];

    url2 = "/admin/display/bookingdetails";

    constructor(private bs:  BookingDetailsService ) {

    }

    ngOnInit() {
        this.bs.retrieveFromServer(this.url2).subscribe(
            data => {
                this.book =  data;
            });
    }

 }
     
 