export class User{
    constructor(public fullname?: string,
        public email?: string,
        public gender?: string,
        public mobile?: number,
        public address?: string,
        public dateOfBirth?: string,
        public password?: string,
        ) { }

}