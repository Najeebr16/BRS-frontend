export class Session{
    constructor(public bus_id?: string,
        public user_id?: string,
        public seats?: string,
        public tfare?: string
        ) { }

}