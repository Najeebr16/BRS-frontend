export class BusAvailability{

    constructor(public source?: string,
        public destination?: string,
        public time?: string,
        public type?: string
        ) { }

}