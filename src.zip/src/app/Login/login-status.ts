export class LoginStatus {

    public userid: string;
    public name: string;
    public status: string;

}
