import { Component } from '@angular/core';


 @Component({
    selector : 'login-user',
    templateUrl : './login-page.component.html'
 })

 export class VerifyLoginComponent{
     title = "Yello";

 }